import userRoutes from "./user.routes.js";
import companyRoutes from "./company.routes.js";

export { userRoutes, companyRoutes }